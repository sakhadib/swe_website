$(document).ready(function () {
    $('#stable').DataTable();
});
